/** Automatically generated file. DO NOT MODIFY */
package com.sjsu.techknowgeek.snakeonaplane;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}