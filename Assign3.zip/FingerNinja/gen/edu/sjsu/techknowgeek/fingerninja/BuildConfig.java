/** Automatically generated file. DO NOT MODIFY */
package edu.sjsu.techknowgeek.fingerninja;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}