Project Group Members:
John Miller
Mark Odell
Nabil Amiri

Server:
The java file should compile and run normally. It listens on port 7890. :)

To set the server ip address, set it in the Set User portion of the app when running on the phone. (no need to change code)

Hungry Frog
The button is a fly! Zap it with your tongue (finger).

Finger Down, Swipe Around
Swipe past the button without lifting your finger. If you do life it, your score is reset!

Rapid Fire
HIT THE BUTTON AS MANY TIMES AS YOU CAN! CAN YOU BEAT OUR HIGH SCORE OF 187?????